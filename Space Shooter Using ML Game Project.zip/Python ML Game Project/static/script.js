const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
canvas.width = 800;
canvas.height = 600;

let player = {
    x: 375,
    y: 500,
    width: 60,
    height: 150,
    speed: 10,
    fastSpeed: 15, // Increased speed for temporary boost
    gunPosition: { x: 390, y: 470 } // Position for shooting
};

let bullets = [];
let asteroids = [];
let score = 0;
let lives = 3;
let gameActive = true;

// UI Elements
const scoreDisplay = document.getElementById("score");
const livesDisplay = document.getElementById("lives");
const quitButton = document.getElementById("quitGame");

// Draw player
function drawPlayer() {
    ctx.fillStyle = "#f0c674"; // Head color
    ctx.beginPath();
    ctx.arc(player.x + player.width / 2, player.y + 30, 30, 0, Math.PI * 2);
    ctx.fill();

    // Draw eyes
    ctx.fillStyle = "black";
    ctx.beginPath();
    ctx.arc(player.x + 20, player.y + 20, 5, 0, Math.PI * 2); // Left eye
    ctx.arc(player.x + 40, player.y + 20, 5, 0, Math.PI * 2); // Right eye
    ctx.fill();

    // Draw mouth
    ctx.fillStyle = "black";
    ctx.fillRect(player.x + 20, player.y + 35, 20, 5);

    // Draw body
    ctx.fillStyle = "#9b59b6"; // Body color
    ctx.fillRect(player.x, player.y + 60, player.width, 40);

    // Draw legs
    ctx.fillStyle = "#34495e"; // Legs color
    ctx.fillRect(player.x, player.y + 100, player.width, 30);

    // Draw gun on left arm
    ctx.fillStyle = "#555"; // Gun color
    ctx.fillRect(player.x + 35, player.y + 50, 10, 15); // Gun part
}

// Move player
function movePlayer(event) {
    if (!gameActive) return;

    // Increase speed temporarily if the keys are pressed
    let speed = player.speed;
    if (event.key === "ArrowLeft" && player.x > 0) {
        player.x -= player.fastSpeed; // Move faster when left arrow is pressed
    }
    if (event.key === "ArrowRight" && player.x < canvas.width - player.width) {
        player.x += player.fastSpeed; // Move faster when right arrow is pressed
    }

    player.gunPosition.x = player.x + 25; // Update gun position
}

// Normal speed after key release
function stopPlayer() {
    player.speed = 10; // Reset speed to normal after key release
}

// Shoot bullet
function shootBullet() {
    if (!gameActive) return;
    bullets.push({ x: player.gunPosition.x, y: player.gunPosition.y });
}

// Draw bullets
function drawBullets() {
    ctx.fillStyle = "yellow";
    bullets.forEach((bullet, index) => {
        bullet.y -= 5;
        ctx.fillRect(bullet.x, bullet.y, 5, 10);
        if (bullet.y < 0) bullets.splice(index, 1);
    });
}

// Spawn asteroids
function spawnAsteroid() {
    if (Math.random() < 0.02) {
        asteroids.push({ x: Math.random() * (canvas.width - 50), y: 0, width: 50, height: 50 });
    }
}

// Draw asteroids
function drawAsteroids() {
    ctx.fillStyle = "red";
    asteroids.forEach((asteroid, index) => {
        asteroid.y += 3;
        ctx.fillRect(asteroid.x, asteroid.y, asteroid.width, asteroid.height);

        if (asteroid.y > canvas.height) {
            asteroids.splice(index, 1);
            lives -= 1;
            updateLives();
            checkGameOver();
        }
    });
}

// Update score display
function updateScore() {
    scoreDisplay.textContent = `Score: ${score}`;
}

// Update lives display
function updateLives() {
    livesDisplay.textContent = `Lives: ${lives}`;
}

// Detect collisions and update score
function detectCollisions() {
    bullets.forEach((bullet, bulletIndex) => {
        asteroids.forEach((asteroid, asteroidIndex) => {
            if (
                bullet.x < asteroid.x + asteroid.width &&
                bullet.x + 5 > asteroid.x &&
                bullet.y < asteroid.y + asteroid.height &&
                bullet.y + 10 > asteroid.y
            ) {
                bullets.splice(bulletIndex, 1);
                asteroids.splice(asteroidIndex, 1);
                score += 10;
                updateScore();
                checkVictory();
            }
        });
    });
}

// Check for victory
function checkVictory() {
    if (score >= 100) {
        endGame("Victory! You've destroyed all asteroids!");
    }
}

// Check for game over
function checkGameOver() {
    if (lives <= 0) {
        endGame("Game Over! You've run out of lives.");
    }
}

// End the game
function endGame(message) {
    gameActive = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "white";
    ctx.font = "30px Arial";
    ctx.fillText(message, canvas.width / 2 - 150, canvas.height / 2);
}

// Quit the game
function quitGame() {
    gameActive = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "white";
    ctx.font = "30px Arial";
    ctx.fillText("Game Ended by Player.", canvas.width / 2 - 150, canvas.height / 2);
}

// Game loop
function gameLoop() {
    if (!gameActive) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawPlayer();
    drawBullets();
    drawAsteroids();
    spawnAsteroid();
    detectCollisions();
    requestAnimationFrame(gameLoop);
}

// Event listeners
document.addEventListener("keydown", movePlayer);
document.addEventListener("keyup", stopPlayer); // Stop player when key is released
document.addEventListener("keydown", (event) => {
    if (event.key === " ") shootBullet();
});
quitButton.addEventListener("click", quitGame);

// Start the game
updateScore();
updateLives();
gameLoop();
