from flask import Flask, request, jsonify
from flask_cors import CORS  # Import CORS
import sqlite3

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Initialize SQLite database
def initialize_database():
    conn = sqlite3.connect('game_data.db')
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS scores (id INTEGER PRIMARY KEY, score INTEGER)")
    conn.commit()
    conn.close()

initialize_database()

@app.route('/save_score', methods=['POST'])
def save_score():
    data = request.json
    score = data.get('score')
    if score is None:
        return jsonify({"message": "Invalid score"}), 400
    conn = sqlite3.connect('game_data.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO scores (score) VALUES (?)", (score,))
    conn.commit()
    conn.close()
    return jsonify({"message": "Score saved successfully!"})

@app.route('/predict_score', methods=['GET'])
def predict_score():
    conn = sqlite3.connect('game_data.db')
    cursor = conn.cursor()
    cursor.execute("SELECT score FROM scores ORDER BY id DESC LIMIT 10")
    scores = [row[0] for row in cursor.fetchall()]
    conn.close()
    if len(scores) < 10:
        return jsonify({"message": "Not enough data to predict"}), 200
    predicted_score = sum(scores) // len(scores)
    return jsonify({"predicted_score": predicted_score})

if __name__ == "__main__":
    app.run(debug=True)
