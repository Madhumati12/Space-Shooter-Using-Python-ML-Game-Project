import pickle
from sklearn.linear_model import LinearRegression

# Example dataset
scores = [10, 20, 15, 30, 25, 40, 35, 50, 45]
X = [scores[i:i+3] for i in range(len(scores)-3)]
y = scores[3:]

model = LinearRegression()
model.fit(X, y)

# Save the model
with open('model.pkl', 'wb') as file:
    pickle.dump(model, file)
